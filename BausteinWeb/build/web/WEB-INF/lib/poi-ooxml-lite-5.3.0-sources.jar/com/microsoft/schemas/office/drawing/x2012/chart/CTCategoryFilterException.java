/*
 * XML Type:  CT_CategoryFilterException
 * Namespace: http://schemas.microsoft.com/office/drawing/2012/chart
 * Java type: com.microsoft.schemas.office.drawing.x2012.chart.CTCategoryFilterException
 *
 * Automatically generated - do not modify.
 */
package com.microsoft.schemas.office.drawing.x2012.chart;

import org.apache.xmlbeans.impl.schema.ElementFactory;
import org.apache.xmlbeans.impl.schema.AbstractDocumentFactory;
import org.apache.xmlbeans.impl.schema.DocumentFactory;
import org.apache.xmlbeans.impl.schema.SimpleTypeFactory;


/**
 * An XML CT_CategoryFilterException(@http://schemas.microsoft.com/office/drawing/2012/chart).
 *
 * This is a complex type.
 */
public interface CTCategoryFilterException extends org.apache.xmlbeans.XmlObject {
    DocumentFactory<com.microsoft.schemas.office.drawing.x2012.chart.CTCategoryFilterException> Factory = new DocumentFactory<>(org.apache.poi.schemas.ooxml.system.ooxml.TypeSystemHolder.typeSystem, "ctcategoryfilterexception2fc2type");
    org.apache.xmlbeans.SchemaType type = Factory.getType();


    /**
     * Gets the "sqref" element
     */
    java.lang.String getSqref();

    /**
     * Gets (as xml) the "sqref" element
     */
    org.apache.xmlbeans.XmlString xgetSqref();

    /**
     * Sets the "sqref" element
     */
    void setSqref(java.lang.String sqref);

    /**
     * Sets (as xml) the "sqref" element
     */
    void xsetSqref(org.apache.xmlbeans.XmlString sqref);

    /**
     * Gets the "spPr" element
     */
    org.openxmlformats.schemas.drawingml.x2006.main.CTShapeProperties getSpPr();

    /**
     * True if has "spPr" element
     */
    boolean isSetSpPr();

    /**
     * Sets the "spPr" element
     */
    void setSpPr(org.openxmlformats.schemas.drawingml.x2006.main.CTShapeProperties spPr);

    /**
     * Appends and returns a new empty "spPr" element
     */
    org.openxmlformats.schemas.drawingml.x2006.main.CTShapeProperties addNewSpPr();

    /**
     * Unsets the "spPr" element
     */
    void unsetSpPr();

    /**
     * Gets the "explosion" element
     */
    org.openxmlformats.schemas.drawingml.x2006.chart.CTUnsignedInt getExplosion();

    /**
     * True if has "explosion" element
     */
    boolean isSetExplosion();

    /**
     * Sets the "explosion" element
     */
    void setExplosion(org.openxmlformats.schemas.drawingml.x2006.chart.CTUnsignedInt explosion);

    /**
     * Appends and returns a new empty "explosion" element
     */
    org.openxmlformats.schemas.drawingml.x2006.chart.CTUnsignedInt addNewExplosion();

    /**
     * Unsets the "explosion" element
     */
    void unsetExplosion();

    /**
     * Gets the "invertIfNegative" element
     */
    org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean getInvertIfNegative();

    /**
     * True if has "invertIfNegative" element
     */
    boolean isSetInvertIfNegative();

    /**
     * Sets the "invertIfNegative" element
     */
    void setInvertIfNegative(org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean invertIfNegative);

    /**
     * Appends and returns a new empty "invertIfNegative" element
     */
    org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean addNewInvertIfNegative();

    /**
     * Unsets the "invertIfNegative" element
     */
    void unsetInvertIfNegative();

    /**
     * Gets the "bubble3D" element
     */
    org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean getBubble3D();

    /**
     * True if has "bubble3D" element
     */
    boolean isSetBubble3D();

    /**
     * Sets the "bubble3D" element
     */
    void setBubble3D(org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean bubble3D);

    /**
     * Appends and returns a new empty "bubble3D" element
     */
    org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean addNewBubble3D();

    /**
     * Unsets the "bubble3D" element
     */
    void unsetBubble3D();

    /**
     * Gets the "marker" element
     */
    org.openxmlformats.schemas.drawingml.x2006.chart.CTMarker getMarker();

    /**
     * True if has "marker" element
     */
    boolean isSetMarker();

    /**
     * Sets the "marker" element
     */
    void setMarker(org.openxmlformats.schemas.drawingml.x2006.chart.CTMarker marker);

    /**
     * Appends and returns a new empty "marker" element
     */
    org.openxmlformats.schemas.drawingml.x2006.chart.CTMarker addNewMarker();

    /**
     * Unsets the "marker" element
     */
    void unsetMarker();

    /**
     * Gets the "dLbl" element
     */
    org.openxmlformats.schemas.drawingml.x2006.chart.CTDLbl getDLbl();

    /**
     * True if has "dLbl" element
     */
    boolean isSetDLbl();

    /**
     * Sets the "dLbl" element
     */
    void setDLbl(org.openxmlformats.schemas.drawingml.x2006.chart.CTDLbl dLbl);

    /**
     * Appends and returns a new empty "dLbl" element
     */
    org.openxmlformats.schemas.drawingml.x2006.chart.CTDLbl addNewDLbl();

    /**
     * Unsets the "dLbl" element
     */
    void unsetDLbl();
}
