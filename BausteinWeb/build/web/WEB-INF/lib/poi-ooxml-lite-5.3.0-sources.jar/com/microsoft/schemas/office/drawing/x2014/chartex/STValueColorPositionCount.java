/*
 * XML Type:  ST_ValueColorPositionCount
 * Namespace: http://schemas.microsoft.com/office/drawing/2014/chartex
 * Java type: com.microsoft.schemas.office.drawing.x2014.chartex.STValueColorPositionCount
 *
 * Automatically generated - do not modify.
 */
package com.microsoft.schemas.office.drawing.x2014.chartex;

import org.apache.xmlbeans.impl.schema.ElementFactory;
import org.apache.xmlbeans.impl.schema.AbstractDocumentFactory;
import org.apache.xmlbeans.impl.schema.DocumentFactory;
import org.apache.xmlbeans.impl.schema.SimpleTypeFactory;


/**
 * An XML ST_ValueColorPositionCount(@http://schemas.microsoft.com/office/drawing/2014/chartex).
 *
 * This is an atomic type that is a restriction of com.microsoft.schemas.office.drawing.x2014.chartex.STValueColorPositionCount.
 */
public interface STValueColorPositionCount extends org.apache.xmlbeans.XmlInt {
    SimpleTypeFactory<com.microsoft.schemas.office.drawing.x2014.chartex.STValueColorPositionCount> Factory = new SimpleTypeFactory<>(org.apache.poi.schemas.ooxml.system.ooxml.TypeSystemHolder.typeSystem, "stvaluecolorpositioncount072ctype");
    org.apache.xmlbeans.SchemaType type = Factory.getType();

}
