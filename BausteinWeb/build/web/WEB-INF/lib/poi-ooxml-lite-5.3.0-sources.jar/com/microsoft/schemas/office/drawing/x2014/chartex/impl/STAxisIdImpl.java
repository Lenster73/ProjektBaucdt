/*
 * XML Type:  ST_AxisId
 * Namespace: http://schemas.microsoft.com/office/drawing/2014/chartex
 * Java type: com.microsoft.schemas.office.drawing.x2014.chartex.STAxisId
 *
 * Automatically generated - do not modify.
 */
package com.microsoft.schemas.office.drawing.x2014.chartex.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.QNameSet;
import org.apache.xmlbeans.XmlObject;

/**
 * An XML ST_AxisId(@http://schemas.microsoft.com/office/drawing/2014/chartex).
 *
 * This is an atomic type that is a restriction of com.microsoft.schemas.office.drawing.x2014.chartex.STAxisId.
 */
public class STAxisIdImpl extends org.apache.xmlbeans.impl.values.JavaLongHolderEx implements com.microsoft.schemas.office.drawing.x2014.chartex.STAxisId {
    private static final long serialVersionUID = 1L;

    public STAxisIdImpl(org.apache.xmlbeans.SchemaType sType) {
        super(sType, false);
    }

    protected STAxisIdImpl(org.apache.xmlbeans.SchemaType sType, boolean b) {
        super(sType, b);
    }
}
