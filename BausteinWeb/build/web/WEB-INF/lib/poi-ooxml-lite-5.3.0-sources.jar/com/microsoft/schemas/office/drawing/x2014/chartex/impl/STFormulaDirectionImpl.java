/*
 * XML Type:  ST_FormulaDirection
 * Namespace: http://schemas.microsoft.com/office/drawing/2014/chartex
 * Java type: com.microsoft.schemas.office.drawing.x2014.chartex.STFormulaDirection
 *
 * Automatically generated - do not modify.
 */
package com.microsoft.schemas.office.drawing.x2014.chartex.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.QNameSet;
import org.apache.xmlbeans.XmlObject;

/**
 * An XML ST_FormulaDirection(@http://schemas.microsoft.com/office/drawing/2014/chartex).
 *
 * This is an atomic type that is a restriction of com.microsoft.schemas.office.drawing.x2014.chartex.STFormulaDirection.
 */
public class STFormulaDirectionImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements com.microsoft.schemas.office.drawing.x2014.chartex.STFormulaDirection {
    private static final long serialVersionUID = 1L;

    public STFormulaDirectionImpl(org.apache.xmlbeans.SchemaType sType) {
        super(sType, false);
    }

    protected STFormulaDirectionImpl(org.apache.xmlbeans.SchemaType sType, boolean b) {
        super(sType, b);
    }
}
