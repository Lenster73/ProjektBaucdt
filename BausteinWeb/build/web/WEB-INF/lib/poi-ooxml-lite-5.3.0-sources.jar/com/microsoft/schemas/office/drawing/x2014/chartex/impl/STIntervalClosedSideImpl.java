/*
 * XML Type:  ST_IntervalClosedSide
 * Namespace: http://schemas.microsoft.com/office/drawing/2014/chartex
 * Java type: com.microsoft.schemas.office.drawing.x2014.chartex.STIntervalClosedSide
 *
 * Automatically generated - do not modify.
 */
package com.microsoft.schemas.office.drawing.x2014.chartex.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.QNameSet;
import org.apache.xmlbeans.XmlObject;

/**
 * An XML ST_IntervalClosedSide(@http://schemas.microsoft.com/office/drawing/2014/chartex).
 *
 * This is an atomic type that is a restriction of com.microsoft.schemas.office.drawing.x2014.chartex.STIntervalClosedSide.
 */
public class STIntervalClosedSideImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements com.microsoft.schemas.office.drawing.x2014.chartex.STIntervalClosedSide {
    private static final long serialVersionUID = 1L;

    public STIntervalClosedSideImpl(org.apache.xmlbeans.SchemaType sType) {
        super(sType, false);
    }

    protected STIntervalClosedSideImpl(org.apache.xmlbeans.SchemaType sType, boolean b) {
        super(sType, b);
    }
}
