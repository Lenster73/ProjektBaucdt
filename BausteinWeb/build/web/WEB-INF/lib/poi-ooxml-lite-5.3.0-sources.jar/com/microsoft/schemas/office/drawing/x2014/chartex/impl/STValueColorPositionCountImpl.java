/*
 * XML Type:  ST_ValueColorPositionCount
 * Namespace: http://schemas.microsoft.com/office/drawing/2014/chartex
 * Java type: com.microsoft.schemas.office.drawing.x2014.chartex.STValueColorPositionCount
 *
 * Automatically generated - do not modify.
 */
package com.microsoft.schemas.office.drawing.x2014.chartex.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.QNameSet;
import org.apache.xmlbeans.XmlObject;

/**
 * An XML ST_ValueColorPositionCount(@http://schemas.microsoft.com/office/drawing/2014/chartex).
 *
 * This is an atomic type that is a restriction of com.microsoft.schemas.office.drawing.x2014.chartex.STValueColorPositionCount.
 */
public class STValueColorPositionCountImpl extends org.apache.xmlbeans.impl.values.JavaIntHolderEx implements com.microsoft.schemas.office.drawing.x2014.chartex.STValueColorPositionCount {
    private static final long serialVersionUID = 1L;

    public STValueColorPositionCountImpl(org.apache.xmlbeans.SchemaType sType) {
        super(sType, false);
    }

    protected STValueColorPositionCountImpl(org.apache.xmlbeans.SchemaType sType, boolean b) {
        super(sType, b);
    }
}
