/*
 * XML Type:  ST_CF
 * Namespace: urn:schemas-microsoft-com:office:excel
 * Java type: com.microsoft.schemas.office.excel.STCF
 *
 * Automatically generated - do not modify.
 */
package com.microsoft.schemas.office.excel;

import org.apache.xmlbeans.impl.schema.ElementFactory;
import org.apache.xmlbeans.impl.schema.AbstractDocumentFactory;
import org.apache.xmlbeans.impl.schema.DocumentFactory;
import org.apache.xmlbeans.impl.schema.SimpleTypeFactory;


/**
 * An XML ST_CF(@urn:schemas-microsoft-com:office:excel).
 *
 * This is an atomic type that is a restriction of com.microsoft.schemas.office.excel.STCF.
 */
public interface STCF extends org.apache.xmlbeans.XmlString {
    SimpleTypeFactory<com.microsoft.schemas.office.excel.STCF> Factory = new SimpleTypeFactory<>(org.apache.poi.schemas.ooxml.system.ooxml.TypeSystemHolder.typeSystem, "stcffa3dtype");
    org.apache.xmlbeans.SchemaType type = Factory.getType();

}
