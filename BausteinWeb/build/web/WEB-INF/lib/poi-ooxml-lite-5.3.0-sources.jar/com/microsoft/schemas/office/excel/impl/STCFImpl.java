/*
 * XML Type:  ST_CF
 * Namespace: urn:schemas-microsoft-com:office:excel
 * Java type: com.microsoft.schemas.office.excel.STCF
 *
 * Automatically generated - do not modify.
 */
package com.microsoft.schemas.office.excel.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.QNameSet;
import org.apache.xmlbeans.XmlObject;

/**
 * An XML ST_CF(@urn:schemas-microsoft-com:office:excel).
 *
 * This is an atomic type that is a restriction of com.microsoft.schemas.office.excel.STCF.
 */
public class STCFImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements com.microsoft.schemas.office.excel.STCF {
    private static final long serialVersionUID = 1L;

    public STCFImpl(org.apache.xmlbeans.SchemaType sType) {
        super(sType, false);
    }

    protected STCFImpl(org.apache.xmlbeans.SchemaType sType, boolean b) {
        super(sType, b);
    }
}
