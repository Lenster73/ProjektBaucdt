/*
 * XML Type:  ST_ObjectType
 * Namespace: urn:schemas-microsoft-com:office:excel
 * Java type: com.microsoft.schemas.office.excel.STObjectType
 *
 * Automatically generated - do not modify.
 */
package com.microsoft.schemas.office.excel.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.QNameSet;
import org.apache.xmlbeans.XmlObject;

/**
 * An XML ST_ObjectType(@urn:schemas-microsoft-com:office:excel).
 *
 * This is an atomic type that is a restriction of com.microsoft.schemas.office.excel.STObjectType.
 */
public class STObjectTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements com.microsoft.schemas.office.excel.STObjectType {
    private static final long serialVersionUID = 1L;

    public STObjectTypeImpl(org.apache.xmlbeans.SchemaType sType) {
        super(sType, false);
    }

    protected STObjectTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b) {
        super(sType, b);
    }
}
