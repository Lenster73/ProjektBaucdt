/*
 * XML Type:  ST_DiagramLayout
 * Namespace: urn:schemas-microsoft-com:office:office
 * Java type: com.microsoft.schemas.office.office.STDiagramLayout
 *
 * Automatically generated - do not modify.
 */
package com.microsoft.schemas.office.office;

import org.apache.xmlbeans.impl.schema.ElementFactory;
import org.apache.xmlbeans.impl.schema.AbstractDocumentFactory;
import org.apache.xmlbeans.impl.schema.DocumentFactory;
import org.apache.xmlbeans.impl.schema.SimpleTypeFactory;


/**
 * An XML ST_DiagramLayout(@urn:schemas-microsoft-com:office:office).
 *
 * This is an atomic type that is a restriction of com.microsoft.schemas.office.office.STDiagramLayout.
 */
public interface STDiagramLayout extends org.apache.xmlbeans.XmlInteger {
    SimpleTypeFactory<com.microsoft.schemas.office.office.STDiagramLayout> Factory = new SimpleTypeFactory<>(org.apache.poi.schemas.ooxml.system.ooxml.TypeSystemHolder.typeSystem, "stdiagramlayout8286type");
    org.apache.xmlbeans.SchemaType type = Factory.getType();

}
